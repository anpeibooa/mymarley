// Use this example configuration file as a starting point for your own files.
{
  // Nuclear structure data files
  structure: [
              {file: "../structure/Te.lev",format: "talys"},
              {file: "../structure/I.lev",format: "talys"},
              {file: "../structure/Xe.lev",format: "talys"},
             ],

  // Reaction matrix element files
  reactions: [ "../react/ve127ICC.react" ],

  // Neutrino source specification
  source: {
   type: "dar",
   neutrino: "ve",       // The source produces electron neutrinos
  },

  // Incident neutrino direction 3-vector
  direction: { x: 0.0,
               y: 1.0,
               z: 0.0
             },

  // Logging configuration
  log: [ { file: "stdout", level: "debug" },
         { file: "marley.log", level: "debug", overwrite: true } ],

  // Settings for marley command-line executable
  executable_settings: {
                         events: 100, // The number of events to generate
                         // Event output configuration
                       output: [ { file: "events.txt", format: "ascii", mode: "overwrite" } ],
  },
}
