// Use this example configuration file as a starting point for your own files.
{
  // Nuclear structure data files
  structure: [
                "../structure/Te.lev",
                "../structure/I.lev",
                "../structure/Xe.lev",
             ],

  // Reaction matrix element files
  reactions: [ "../react/ve127ICC.react" ],

  // Neutrino source specification
  source: {
   type: "th1",
   neutrino: "ve",       // The source produces electron neutrinos
   tfile: "../my_nu_spectrum.root",
   namecycle: "MyHist",
  },

  // Incident neutrino direction 3-vector
  direction: { x: 0.0,
               y: 1.0,
               z: 0.0
             },

  // Logging configuration
  log: [ { file: "stdout", level: "debug" },
         { file: "marley.log", level: "debug", overwrite: true } ],

  // Settings for marley command-line executable
  executable_settings: {
                         events: 1000, // The number of events to generate
                         // Event output configuration
                       output: [ { file: "events.txt", format: "ascii", mode: "overwrite" } ],
  },
}
